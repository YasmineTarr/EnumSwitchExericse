import UIKit

enum sandwich: CaseIterable {
    case pickles,cheese, bacon, penutButter, jelly, mayo, lettuce
}

print("I'll have")
//bread
for sandwich in sandwich.allCases {
    print (sandwich)
//bread
}

print("on my sandwich")

// i think this is neat becuase its kind of stacked like a sandwich
